package main

import (
	"bytes"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"kmip-server/kmip"
	"log"
	"os"
	"time"
)

func main() {
	// 커맨드 라인 플래그
	addr := flag.String("addr", "localhost:5696", "KMIP server address")
	certFile := flag.String("cert", "", "Client certificate file (optional)")
	keyFile := flag.String("key", "", "Client private key file (optional)")
	caFile := flag.String("ca", "", "CA certificate file")
	operation := flag.String("op", "query", "Operation to perform: query, create, get, destroy")
	keyID := flag.String("id", "", "Key ID for get/destroy operations")
	flag.Parse()

	log.Printf("Connecting to KMIP server at %s", *addr)

	// TLS 설정
	tlsConfig, err := createClientTLSConfig(*certFile, *keyFile, *caFile)
	if err != nil {
		log.Fatalf("Failed to create TLS config: %v", err)
	}

	// 서버 연결
	conn, err := tls.Dial("tcp", *addr, tlsConfig)
	if err != nil {
		log.Fatalf("Failed to connect to server: %v", err)
	}
	defer conn.Close()

	log.Println("Connected to KMIP server")

	// 요청 생성
	var requestData []byte
	switch *operation {
	case "query":
		requestData, err = createQueryRequest()
	case "create":
		requestData, err = createCreateRequest()
	case "discover":
		requestData, err = createDiscoverVersionsRequest()
	default:
		log.Fatalf("Unsupported operation: %s", *operation)
	}

	if err != nil {
		log.Fatalf("Failed to create request: %v", err)
	}

	// 요청 전송
	log.Printf("Sending %d bytes to server", len(requestData))
	_, err = conn.Write(requestData)
	if err != nil {
		log.Fatalf("Failed to send request: %v", err)
	}

	// 응답 수신
	buf := make([]byte, 65536)
	n, err := conn.Read(buf)
	if err != nil {
		log.Fatalf("Failed to read response: %v", err)
	}

	responseData := buf[:n]
	log.Printf("Received %d bytes from server", n)

	// 응답 파싱
	err = parseResponse(responseData)
	if err != nil {
		log.Fatalf("Failed to parse response: %v", err)
	}
}

// createClientTLSConfig는 클라이언트 TLS 설정을 생성
func createClientTLSConfig(certFile, keyFile, caFile string) (*tls.Config, error) {
	config := &tls.Config{
		MinVersion: tls.VersionTLS12,
	}

	// CA 인증서 로드
	if caFile != "" {
		caCert, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}

		caCertPool := x509.NewCertPool()
		caCertPool.AppendCertsFromPEM(caCert)
		config.RootCAs = caCertPool
	} else {
		// CA가 없으면 InsecureSkipVerify (테스트 목적)
		config.InsecureSkipVerify = true
		log.Println("Warning: Skipping certificate verification")
	}

	// 클라이언트 인증서 로드 (선택적)
	if certFile != "" && keyFile != "" {
		cert, err := tls.LoadX509KeyPair(certFile, keyFile)
		if err != nil {
			return nil, err
		}
		config.Certificates = []tls.Certificate{cert}
		log.Println("Using client certificate authentication")
	}

	return config, nil
}

// createQueryRequest는 Query 요청 메시지를 생성
func createQueryRequest() ([]byte, error) {
	var buf bytes.Buffer

	// Protocol Version
	protocolVersion := &kmip.TTLVItem{
		Tag:  kmip.TagProtocolVersion,
		Type: kmip.TypeStructure,
		Value: []*kmip.TTLVItem{
			{Tag: kmip.TagProtocolVersionMajor, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
			{Tag: kmip.TagProtocolVersionMinor, Type: kmip.TypeInteger, Length: 4, Value: int32(0)},
		},
	}

	// Request Header
	headerItems := []*kmip.TTLVItem{
		protocolVersion,
		{Tag: kmip.TagBatchCount, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
	}
	headerLength := calculateStructureLength(headerItems)
	requestHeader := &kmip.TTLVItem{
		Tag:    kmip.TagRequestHeader,
		Type:   kmip.TypeStructure,
		Length: headerLength,
		Value:  headerItems,
	}

	// Batch Item
	batchItems := []*kmip.TTLVItem{
		{Tag: kmip.TagOperation, Type: kmip.TypeEnumeration, Length: 4, Value: int32(kmip.OperationQuery)},
	}
	batchLength := calculateStructureLength(batchItems)
	batchItem := &kmip.TTLVItem{
		Tag:    kmip.TagBatchItem,
		Type:   kmip.TypeStructure,
		Length: batchLength,
		Value:  batchItems,
	}

	// Request Message
	reqItems := []*kmip.TTLVItem{requestHeader, batchItem}
	reqLength := calculateStructureLength(reqItems)
	requestMessage := &kmip.TTLVItem{
		Tag:    kmip.TagRequestMessage,
		Type:   kmip.TypeStructure,
		Length: reqLength,
		Value:  reqItems,
	}

	if err := kmip.EncodeTTLV(&buf, requestMessage); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// createCreateRequest는 Create 요청 메시지를 생성
func createCreateRequest() ([]byte, error) {
	var buf bytes.Buffer

	// Protocol Version
	protocolVersion := &kmip.TTLVItem{
		Tag:  kmip.TagProtocolVersion,
		Type: kmip.TypeStructure,
		Value: []*kmip.TTLVItem{
			{Tag: kmip.TagProtocolVersionMajor, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
			{Tag: kmip.TagProtocolVersionMinor, Type: kmip.TypeInteger, Length: 4, Value: int32(0)},
		},
	}

	// Request Header
	headerItems := []*kmip.TTLVItem{
		protocolVersion,
		{Tag: kmip.TagBatchCount, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
	}
	headerLength := calculateStructureLength(headerItems)
	requestHeader := &kmip.TTLVItem{
		Tag:    kmip.TagRequestHeader,
		Type:   kmip.TypeStructure,
		Length: headerLength,
		Value:  headerItems,
	}

	// Batch Item
	batchItems := []*kmip.TTLVItem{
		{Tag: kmip.TagOperation, Type: kmip.TypeEnumeration, Length: 4, Value: int32(kmip.OperationCreate)},
		{Tag: kmip.TagObjectType, Type: kmip.TypeEnumeration, Length: 4, Value: int32(kmip.ObjectTypeSymmetricKey)},
	}
	batchLength := calculateStructureLength(batchItems)
	batchItem := &kmip.TTLVItem{
		Tag:    kmip.TagBatchItem,
		Type:   kmip.TypeStructure,
		Length: batchLength,
		Value:  batchItems,
	}

	// Request Message
	reqItems := []*kmip.TTLVItem{requestHeader, batchItem}
	reqLength := calculateStructureLength(reqItems)
	requestMessage := &kmip.TTLVItem{
		Tag:    kmip.TagRequestMessage,
		Type:   kmip.TypeStructure,
		Length: reqLength,
		Value:  reqItems,
	}

	if err := kmip.EncodeTTLV(&buf, requestMessage); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// createDiscoverVersionsRequest는 DiscoverVersions 요청 메시지를 생성
func createDiscoverVersionsRequest() ([]byte, error) {
	var buf bytes.Buffer

	// Protocol Version
	protocolVersion := &kmip.TTLVItem{
		Tag:  kmip.TagProtocolVersion,
		Type: kmip.TypeStructure,
		Value: []*kmip.TTLVItem{
			{Tag: kmip.TagProtocolVersionMajor, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
			{Tag: kmip.TagProtocolVersionMinor, Type: kmip.TypeInteger, Length: 4, Value: int32(0)},
		},
	}

	// Request Header
	headerItems := []*kmip.TTLVItem{
		protocolVersion,
		{Tag: kmip.TagBatchCount, Type: kmip.TypeInteger, Length: 4, Value: int32(1)},
	}
	headerLength := calculateStructureLength(headerItems)
	requestHeader := &kmip.TTLVItem{
		Tag:    kmip.TagRequestHeader,
		Type:   kmip.TypeStructure,
		Length: headerLength,
		Value:  headerItems,
	}

	// Batch Item
	batchItems := []*kmip.TTLVItem{
		{Tag: kmip.TagOperation, Type: kmip.TypeEnumeration, Length: 4, Value: int32(kmip.OperationDiscoverVersions)},
	}
	batchLength := calculateStructureLength(batchItems)
	batchItem := &kmip.TTLVItem{
		Tag:    kmip.TagBatchItem,
		Type:   kmip.TypeStructure,
		Length: batchLength,
		Value:  batchItems,
	}

	// Request Message
	reqItems := []*kmip.TTLVItem{requestHeader, batchItem}
	reqLength := calculateStructureLength(reqItems)
	requestMessage := &kmip.TTLVItem{
		Tag:    kmip.TagRequestMessage,
		Type:   kmip.TypeStructure,
		Length: reqLength,
		Value:  reqItems,
	}

	if err := kmip.EncodeTTLV(&buf, requestMessage); err != nil {
		return nil, err
	}

	return buf.Bytes(), nil
}

// parseResponse는 응답 메시지를 파싱하고 출력
func parseResponse(data []byte) error {
	reader := bytes.NewReader(data)
	item, err := kmip.DecodeTTLV(reader)
	if err != nil {
		return err
	}

	fmt.Println("\n=== KMIP Response ===")
	printTTLVItem(item, 0)
	return nil
}

// printTTLVItem은 TTLV 아이템을 출력
func printTTLVItem(item *kmip.TTLVItem, indent int) {
	prefix := ""
	for i := 0; i < indent; i++ {
		prefix += "  "
	}

	tagName := getTagName(item.Tag)
	typeName := getTypeName(item.Type)

	fmt.Printf("%sTag: %s (0x%06X), Type: %s, Length: %d\n",
		prefix, tagName, item.Tag, typeName, item.Length)

	if item.Type == kmip.TypeStructure {
		if items, ok := item.Value.([]*kmip.TTLVItem); ok {
			for _, subItem := range items {
				printTTLVItem(subItem, indent+1)
			}
		}
	} else {
		fmt.Printf("%s  Value: %v\n", prefix, item.Value)
	}
}

// getTagName은 태그 이름을 반환
func getTagName(tag kmip.Tag) string {
	switch tag {
	case kmip.TagRequestMessage:
		return "RequestMessage"
	case kmip.TagResponseMessage:
		return "ResponseMessage"
	case kmip.TagRequestHeader:
		return "RequestHeader"
	case kmip.TagResponseHeader:
		return "ResponseHeader"
	case kmip.TagProtocolVersion:
		return "ProtocolVersion"
	case kmip.TagProtocolVersionMajor:
		return "ProtocolVersionMajor"
	case kmip.TagProtocolVersionMinor:
		return "ProtocolVersionMinor"
	case kmip.TagBatchCount:
		return "BatchCount"
	case kmip.TagBatchItem:
		return "BatchItem"
	case kmip.TagOperation:
		return "Operation"
	case kmip.TagResultStatus:
		return "ResultStatus"
	case kmip.TagResultMessage:
		return "ResultMessage"
	case kmip.TagUniqueIdentifier:
		return "UniqueIdentifier"
	case kmip.TagTimeStamp:
		return "TimeStamp"
	default:
		return "Unknown"
	}
}

// getTypeName은 타입 이름을 반환
func getTypeName(t kmip.Type) string {
	switch t {
	case kmip.TypeStructure:
		return "Structure"
	case kmip.TypeInteger:
		return "Integer"
	case kmip.TypeLongInteger:
		return "LongInteger"
	case kmip.TypeEnumeration:
		return "Enumeration"
	case kmip.TypeBoolean:
		return "Boolean"
	case kmip.TypeTextString:
		return "TextString"
	case kmip.TypeByteString:
		return "ByteString"
	default:
		return "Unknown"
	}
}

// calculateStructureLength는 Structure의 길이를 계산
func calculateStructureLength(items []*kmip.TTLVItem) uint32 {
	var length uint32
	for _, item := range items {
		// Tag(3) + Type(1) + Length(4) + Value (패딩 포함)
		length += 8 + paddedLength(item.Length)
	}
	return length
}

// paddedLength는 8바이트 경계로 패딩된 길이를 계산
func paddedLength(length uint32) uint32 {
	return ((length + 7) / 8) * 8
}
