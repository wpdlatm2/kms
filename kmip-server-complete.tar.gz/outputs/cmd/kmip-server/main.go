package main

import (
	"crypto/tls"
	"crypto/x509"
	"flag"
	"io"
	"kmip-server/kmip"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"
)

func main() {
	// 커맨드 라인 플래그
	addr := flag.String("addr", ":5696", "KMIP server address (default KMIP port 5696)")
	certFile := flag.String("cert", "server.crt", "TLS certificate file")
	keyFile := flag.String("key", "server.key", "TLS private key file")
	caFile := flag.String("ca", "", "CA certificate file for client authentication (optional)")
	
	// Raft 설정
	configFile := flag.String("config", "", "Configuration file (YAML or JSON)")
	nodeID := flag.String("node-id", "node-1", "Raft node ID")
	raftAddr := flag.String("raft-addr", "127.0.0.1:7000", "Raft bind address")
	dataDir := flag.String("data-dir", "./data", "Raft data directory")
	bootstrap := flag.Bool("bootstrap", false, "Bootstrap a new Raft cluster")
	httpAddr := flag.String("http-addr", ":8080", "HTTP management API address")
	useRaft := flag.Bool("use-raft", false, "Use Raft distributed storage (default: in-memory)")
	
	// 복제 설정
	replicationEnabled := flag.Bool("replication", true, "Enable replication")
	replicationMode := flag.String("replication-mode", "quorum", "Replication mode: sync, async, quorum")
	replicationFactor := flag.Int("replication-factor", 3, "Replication factor")
	minReplicas := flag.Int("min-replicas", 2, "Minimum replicas for quorum")
	
	// REST API 설정
	restAddr := flag.String("rest-addr", ":9090", "REST API address")
	enableREST := flag.Bool("enable-rest", false, "Enable REST API")
	
	flag.Parse()

	log.Printf("Starting KMIP Server on %s", *addr)
	log.Println("Supported KMIP versions: 1.0, 1.1, 1.2, 1.3, 1.4, 2.0, 2.1, 3.0")

	// TLS 설정
	tlsConfig, err := createTLSConfig(*certFile, *keyFile, *caFile)
	if err != nil {
		log.Fatalf("Failed to create TLS config: %v", err)
	}

	// 저장소 생성
	var store kmip.ObjectStore
	var clusterManager *kmip.ClusterManager
	
	if *useRaft {
		log.Printf("Using Raft distributed storage")
		
		var raftConfig *kmip.RaftConfig
		var raftPolicy *kmip.ReplicationPolicy
		
		// 설정 파일이 제공된 경우
		if *configFile != "" {
			log.Printf("Loading configuration from: %s", *configFile)
			raftConfig, raftPolicy, err = kmip.LoadConfigFromYAML(*configFile)
			if err != nil {
				log.Fatalf("Failed to load config: %v", err)
			}
		} else {
			// 커맨드 라인 플래그로 설정
			log.Printf("Using command-line configuration")
			raftConfig = &kmip.RaftConfig{
				NodeID:              *nodeID,
				BindAddr:            *raftAddr,
				DataDir:             *dataDir,
				Bootstrap:           *bootstrap,
				ReplicationEnabled:  *replicationEnabled,
				ReplicationFactor:   *replicationFactor,
				MinReplicas:         *minReplicas,
			}
			
			// 복제 모드 설정
			var mode kmip.ReplicationMode
			switch *replicationMode {
			case "sync":
				mode = kmip.ReplicationModeSync
			case "async":
				mode = kmip.ReplicationModeAsync
			case "quorum":
				mode = kmip.ReplicationModeQuorum
			default:
				mode = kmip.ReplicationModeQuorum
			}
			
			raftPolicy = &kmip.ReplicationPolicy{
				Mode:              mode,
				MinAcks:           *minReplicas,
				TimeoutMs:         5000,
				RetryAttempts:     3,
				RetryBackoffMs:    100,
				ConsistencyLevel:  "strong",
			}
		}
		
		// 설정 정보 출력
		log.Printf("Node ID: %s", raftConfig.NodeID)
		log.Printf("Raft address: %s", raftConfig.BindAddr)
		log.Printf("Data directory: %s", raftConfig.DataDir)
		log.Printf("Bootstrap mode: %v", raftConfig.Bootstrap)
		log.Printf("Replication enabled: %v", raftConfig.ReplicationEnabled)
		if raftConfig.ReplicationEnabled {
			log.Printf("Replication mode: %s", raftPolicy.Mode)
			log.Printf("Replication factor: %d", raftConfig.ReplicationFactor)
			log.Printf("Min replicas: %d", raftConfig.MinReplicas)
		}
		
		// Raft 저장소 생성
		raftStore, err := kmip.NewRaftStore(raftConfig, raftPolicy)
		if err != nil {
			log.Fatalf("Failed to create Raft store: %v", err)
		}
		store = raftStore
		
		// 클러스터 관리 API 시작 (복제가 활성화된 경우에만)
		if raftConfig.ReplicationEnabled {
			clusterManager = kmip.NewClusterManager(raftStore)
			go func() {
				log.Printf("Starting HTTP management API on %s", *httpAddr)
				if err := clusterManager.ServeHTTP(*httpAddr); err != nil {
					log.Printf("HTTP server error: %v", err)
				}
			}()
		}
		// 종료 시그널 처리
		defer func() {
			log.Println("Shutting down Raft...")
			if err := raftStore.Shutdown(); err != nil {
				log.Printf("Error shutting down Raft: %v", err)
			}
		}()
	} else {
		log.Printf("Using in-memory storage")
		store = kmip.NewInMemoryStore()
	}

	// KMIP 서버 생성
	kmipServer := kmip.NewServer(store)

	// REST API 서버 시작 (선택적)
	if *enableREST {
		restAPI := kmip.NewRESTAPIServer(kmipServer)
		go func() {
			log.Printf("Starting REST API server on %s", *restAddr)
			if err := restAPI.ServeHTTP(*restAddr); err != nil {
				log.Printf("REST API server error: %v", err)
			}
		}()
	}

	// TLS 리스너 시작
	listener, err := tls.Listen("tcp", *addr, tlsConfig)
	if err != nil {
		log.Fatalf("Failed to start listener: %v", err)
	}
	defer listener.Close()

	log.Printf("KMIP Server listening on %s with TLS", *addr)

	// 종료 시그널 처리
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)
	
	// 연결 처리 고루틴
	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				log.Printf("Failed to accept connection: %v", err)
				continue
			}

			go handleConnection(conn, kmipServer)
		}
	}()
	
	// 종료 시그널 대기
	<-sigChan
	log.Println("Shutting down server...")
}

// createTLSConfig는 TLS 설정을 생성
func createTLSConfig(certFile, keyFile, caFile string) (*tls.Config, error) {
	cert, err := tls.LoadX509KeyPair(certFile, keyFile)
	if err != nil {
		return nil, err
	}

	config := &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS12,
		CipherSuites: []uint16{
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
		},
	}

	// 클라이언트 인증 설정 (선택적)
	if caFile != "" {
		caCert, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}

		caCertPool := x509.NewCertPool()
		caCertPool.AppendCertsFromPEM(caCert)

		config.ClientCAs = caCertPool
		config.ClientAuth = tls.RequireAndVerifyClientCert
		log.Println("Client certificate authentication enabled")
	}

	return config, nil
}

// handleConnection은 클라이언트 연결을 처리
func handleConnection(conn net.Conn, server *kmip.Server) {
	defer conn.Close()

	clientAddr := conn.RemoteAddr().String()
	log.Printf("New connection from %s", clientAddr)

	// 요청 읽기
	buf := make([]byte, 65536) // 64KB 버퍼
	n, err := conn.Read(buf)
	if err != nil {
		if err != io.EOF {
			log.Printf("Error reading from %s: %v", clientAddr, err)
		}
		return
	}

	requestData := buf[:n]
	log.Printf("Received %d bytes from %s", n, clientAddr)

	// 요청 처리
	responseData, err := server.ProcessRequest(requestData)
	if err != nil {
		log.Printf("Error processing request from %s: %v", clientAddr, err)
		return
	}

	// 응답 전송
	_, err = conn.Write(responseData)
	if err != nil {
		log.Printf("Error writing to %s: %v", clientAddr, err)
		return
	}

	log.Printf("Sent %d bytes to %s", len(responseData), clientAddr)
}
